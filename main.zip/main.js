
function fun_title(){
	document.title="1 новое сообщение"
}
function fun_title2(){
	document.title="2 новых сообщения"
}


function fun1(){
alert("Вы нажали кнопку");
}


function fon1(){
	document.getElementById('content').style.backgroundImage = "url('img/white.png')"
}

function fon2(){
	document.getElementById('content').style.backgroundImage = "url('img/kale-salad.jpg')"
}
function fon3(){
	document.getElementById('content').style.backgroundImage = "url('img/brijan.gif')"
}

function changeback(){
	document.getElementById('content').style.backgroundImage = "url('img/white.png')"
}

function fun2(){
document.getElementById('part1').innerHTML="Доброе утро";
document.getElementById('part1').style.fontSize='60px';
document.getElementById('part1').style.color='blue';
// document.title="1 новое сообщеие";
}
function fun3(){
document.getElementById("part1").innerHTML="Добрый вечер";
document.getElementById('part1').style.fontSize='60px';
document.getElementById('part1').style.color='green';
}

// function title(){
// 	document.getElementById("main_title").innerHTML="сообщение";
// }

function fun_on_led(){
document.getElementById('myImage').src='img/pic_bulbon.gif'
}
function fun_off_led(){
document.getElementById('myImage').src='img/pic_bulboff.gif'
}

function fulltime() {

	var time=new Date();

	document.clock.full.value=time.toLocaleString();

	setTimeout('fulltime()',1000)

}

 var now = new Date();
 alert(now.getHours());


 function showPlus(a,b){
 alert(a+b);
 }
